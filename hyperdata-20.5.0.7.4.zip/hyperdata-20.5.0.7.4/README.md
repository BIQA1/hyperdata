# Hyperdata

본 문서는 Hyperdata 종합 가이드입니다.

현재 제공되는 기능은 총 2가지입니다.

1. [Hyperdata 이미지를 빌드하고 Push하는 빌드 서버](./build)

2. [Hyperdata 및 관련 모듈들을 설치하는 installer](./install)